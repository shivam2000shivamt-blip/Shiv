# 🤖 JARVIS AI — Flutter Voice Assistant

Original Jarvis-AI repo se inspired ek naya, fixed aur improved version — **aapki apni Gemini API key** ke saath, hardcoded nahi.

## ✅ Fixed / Improved (Original repo se):
- ❌ Original me API key hardcoded thi → ✅ ab **Settings screen** se user apni key daalta hai (kabhi expose nahi hota, sirf device par stored)
- ✅ Proper **error handling**: invalid key, no internet, rate-limit, empty response — sab cases handle ho gaye, app crash nahi karega
- ✅ "API key not configured" ka message dega, crash ki jagah
- ✅ Clean modular code (services / screens / widgets separate)

## ✨ New Features Added:
1. **Settings Screen** — Gemini API key, your name, assistant name, voice rate/pitch — sab customizable. "Test Key" button bhi hai.
2. **Notes / Reminders** — "remember that..." bolo, baad me "what did I ask you to remember" se sun sakte ho.
3. **Live Weather** (Open-Meteo, free, no extra key) — GPS location se real weather.
4. **Battery status, network status, time, date** — sab offline (no API call needed)
5. **WhatsApp messaging** — "send whatsapp message to <number> saying <text>"
6. **App launching** — WhatsApp, YouTube, Instagram, Chrome, Maps, Spotify, etc.
7. **Web/YouTube search by voice**
8. **Animated JARVIS orb UI** — color/pulse changes: listening (red), thinking (orange), speaking (green), idle (cyan)
9. **ASCII-style shutdown screen** on "bye"/"goodbye jarvis" (Iron Man easter egg, like original)
10. **Local jokes** — no API call wasted on jokes
11. **Chat-style conversation history** on screen
12. **🔔 Alarm** — "set an alarm for 7:30 am" (opens device Clock app, alarm set)
13. **⏱ Timer** — "set a timer for 5 minutes"
14. **🔦 Flashlight** — "turn on flashlight" / "turn off flashlight"
15. **🧮 Calculator** — "calculate 25 * 4 + 10" / "what is 100 divided by 4"

## 📲 How to get the APK file:

Mere is environment me Flutter SDK / Android SDK nahi hai, isliye main directly APK nahi bana sakta. Aap ye steps follow karo (5-10 min):

1. **Flutter install karo**: https://docs.flutter.dev/get-started/install
2. Is project ka zip download/extract karo
3. Terminal me project folder me jao:
   ```bash
   cd jarvis_ai
   flutter pub get
   flutter build apk --release
   ```
4. APK yaha milegi: `build/app/outputs/flutter-apk/app-release.apk`
5. Phone me transfer karo, install karo (unknown sources allow karna padega)

**Easier alternative**: [GitHub Codespaces](https://github.com/codespaces) ya [Codemagic](https://codemagic.io) (free tier) use karke bina apna PC setup kiye, cloud me APK build kar sakte ho — repo upload karo, "flutter build apk" command chalao, APK download kar lo.


## 🔑 Setup — Apni Gemini API Key kaise lagayein:

1. Free key lo: https://aistudio.google.com/app/apikey
2. App open karo → top-right **⚙ Settings** icon
3. API key paste karo → "Test Key" dabao (verify hoga)
4. Apna naam, assistant ka naam, voice speed/pitch set karo
5. Save karo — done! 100% aapki key, sirf aapke phone me save hoti hai.

## 🛠 How to Run:

```bash
flutter pub get
flutter run
```

Build APK:
```bash
flutter build apk --release
```

## 🎤 Voice Commands Examples:
- "What time is it?"
- "What's the weather?"
- "Tell me a joke"
- "Open WhatsApp" / "Open YouTube" / "Open Instagram"
- "Search for flutter tutorials"
- "Play despacito on youtube"
- "Call 9876543210"
- "Send whatsapp message to 919876543210 saying hello"
- "Remember that my exam is on Monday"
- "What did I ask you to remember?"
- "What's the battery level?"
- "Set an alarm for 7:30 am"
- "Set a timer for 5 minutes"
- "Turn on the flashlight" / "Turn off the flashlight"
- "Calculate 25 times 4 plus 10"
- "Goodbye Jarvis" (shutdown animation)
- Anything else → goes to **Gemini AI** for a smart reply

## 📦 Required Permissions:
- Microphone (voice input)
- Location (weather)
- Phone (calling)
- Internet

## ⚠️ Notes:
- Gemini model used: `gemini-2.0-flash` (fast + free tier friendly)
- Weather uses Open-Meteo — completely free, no key needed
- App launching package list can be extended in `device_service.dart`
