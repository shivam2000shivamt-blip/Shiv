import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/prefs_service.dart';
import '../services/gemini_service.dart';
import '../utils/theme.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _apiKeyController = TextEditingController();
  final _userNameController = TextEditingController();
  final _assistantNameController = TextEditingController();

  bool _obscureKey = true;
  bool _validating = false;
  String? _validationMessage;
  bool? _isValid;

  double _speechRate = 0.5;
  double _voicePitch = 1.0;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final apiKey = await PrefsService.getApiKey();
    final userName = await PrefsService.getUserName();
    final assistantName = await PrefsService.getAssistantName();
    final rate = await PrefsService.getSpeechRate();
    final pitch = await PrefsService.getVoicePitch();

    setState(() {
      _apiKeyController.text = apiKey ?? '';
      _userNameController.text = userName;
      _assistantNameController.text = assistantName;
      _speechRate = rate;
      _voicePitch = pitch;
    });
  }

  Future<void> _save() async {
    await PrefsService.setApiKey(_apiKeyController.text);
    await PrefsService.setUserName(
        _userNameController.text.isEmpty ? 'Sir' : _userNameController.text);
    await PrefsService.setAssistantName(_assistantNameController.text.isEmpty
        ? 'Jarvis'
        : _assistantNameController.text);
    await PrefsService.setSpeechRate(_speechRate);
    await PrefsService.setVoicePitch(_voicePitch);

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Settings saved.')),
      );
    }
  }

  Future<void> _validateKey() async {
    final key = _apiKeyController.text.trim();
    if (key.isEmpty) {
      setState(() {
        _isValid = false;
        _validationMessage = 'Please enter an API key first.';
      });
      return;
    }
    setState(() {
      _validating = true;
      _validationMessage = null;
      _isValid = null;
    });

    final ok = await GeminiService.validateKey(key);

    setState(() {
      _validating = false;
      _isValid = ok;
      _validationMessage =
          ok ? 'API key is valid and working!' : 'Invalid key or no internet connection.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SETTINGS')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'GEMINI API KEY',
              style: TextStyle(
                  color: JarvisTheme.primaryCyan,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5),
            ),
            const SizedBox(height: 8),
            const Text(
              'Jarvis uses YOUR own Google Gemini API key. It is stored '
              'only on this device and never shared.',
              style: TextStyle(color: Colors.white60, fontSize: 12),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _apiKeyController,
              obscureText: _obscureKey,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Paste your Gemini API key here',
                suffixIcon: IconButton(
                  icon: Icon(_obscureKey ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _obscureKey = !_obscureKey),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton(
                  onPressed: _validating ? null : _validateKey,
                  child: _validating
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Text('Test Key'),
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: () async {
                    await launchUrl(
                      Uri.parse('https://aistudio.google.com/app/apikey'),
                      mode: LaunchMode.externalApplication,
                    );
                  },
                  child: const Text('Get a free API key →'),
                ),
              ],
            ),
            if (_validationMessage != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  _validationMessage!,
                  style: TextStyle(
                    color: _isValid == true ? Colors.greenAccent : JarvisTheme.errorRed,
                    fontSize: 13,
                  ),
                ),
              ),

            const Divider(height: 32, color: Colors.white24),

            const Text(
              'PERSONALIZATION',
              style: TextStyle(
                  color: JarvisTheme.primaryCyan,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _userNameController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Your name',
                labelStyle: TextStyle(color: Colors.white60),
                hintText: 'e.g. Tony',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _assistantNameController,
              style: const TextStyle(color: Colors.white),
              decoration: const InputDecoration(
                labelText: 'Assistant name',
                labelStyle: TextStyle(color: Colors.white60),
                hintText: 'e.g. Jarvis',
              ),
            ),

            const Divider(height: 32, color: Colors.white24),

            const Text(
              'VOICE SETTINGS',
              style: TextStyle(
                  color: JarvisTheme.primaryCyan,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5),
            ),
            const SizedBox(height: 8),
            Text('Speech Rate: ${_speechRate.toStringAsFixed(2)}',
                style: const TextStyle(color: Colors.white70)),
            Slider(
              value: _speechRate,
              min: 0.1,
              max: 1.0,
              activeColor: JarvisTheme.primaryCyan,
              onChanged: (v) => setState(() => _speechRate = v),
            ),
            Text('Voice Pitch: ${_voicePitch.toStringAsFixed(2)}',
                style: const TextStyle(color: Colors.white70)),
            Slider(
              value: _voicePitch,
              min: 0.5,
              max: 2.0,
              activeColor: JarvisTheme.primaryCyan,
              onChanged: (v) => setState(() => _voicePitch = v),
            ),

            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () async {
                  await _save();
                  if (mounted) Navigator.pop(context);
                },
                icon: const Icon(Icons.save),
                label: const Text('SAVE SETTINGS'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
