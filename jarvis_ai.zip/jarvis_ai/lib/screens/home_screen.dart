import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/speech_service.dart';
import '../services/command_processor.dart';
import '../services/prefs_service.dart';
import '../services/notes_service.dart';
import '../utils/theme.dart';
import '../widgets/jarvis_orb.dart';
import '../widgets/chat_bubble.dart';

class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage(this.text, this.isUser);
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  final SpeechService _speechService = SpeechService();
  final CommandProcessor _processor = CommandProcessor();
  final TextEditingController _textController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<ChatMessage> _messages = [];

  bool _isListening = false;
  bool _isThinking = false;
  bool _isSpeaking = false;
  String _partialText = '';
  String _assistantName = 'Jarvis';
  bool _showAsciiOutro = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await Permission.microphone.request();
    await Permission.locationWhenInUse.request();
    await _speechService.init();
    final name = await PrefsService.getAssistantName();
    setState(() => _assistantName = name);

    _addMessage(
        "${_assistantName.toUpperCase()} online. How can I help you, "
        "${await PrefsService.getUserName()}?",
        false);
  }

  void _addMessage(String text, bool isUser) {
    setState(() {
      _messages.add(ChatMessage(text, isUser));
    });
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _handleInput(String text) async {
    if (text.trim().isEmpty) return;
    _addMessage(text, true);
    _textController.clear();

    setState(() => _isThinking = true);
    final result = await _processor.process(text);
    setState(() => _isThinking = false);

    _addMessage(result.response, false);

    setState(() => _isSpeaking = true);
    await _speechService.speak(result.response);
    setState(() => _isSpeaking = false);

    // Easter egg: ASCII shutdown animation on goodbye
    final lower = text.toLowerCase();
    if (lower.contains('bye') ||
        lower.contains('goodbye jarvis') ||
        lower.contains('shutdown')) {
      _triggerAsciiOutro();
    }
  }

  void _triggerAsciiOutro() {
    setState(() => _showAsciiOutro = true);
    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) setState(() => _showAsciiOutro = false);
    });
  }

  Future<void> _toggleListening() async {
    if (_isListening) {
      await _speechService.stopListening();
      setState(() => _isListening = false);
      return;
    }

    if (!_speechService.speechEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Microphone permission required.')),
      );
      return;
    }

    setState(() {
      _isListening = true;
      _partialText = '';
    });

    await _speechService.startListening(
      onPartial: (partial) {
        setState(() => _partialText = partial);
      },
      onResult: (finalText) async {
        setState(() {
          _isListening = false;
          _partialText = '';
        });
        if (finalText.trim().isNotEmpty) {
          await _handleInput(finalText);
        }
      },
    );
  }

  void _showNotes() async {
    final notes = await NotesService.getAll();
    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: JarvisTheme.cardDark,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'SAVED NOTES (${notes.length})',
                style: const TextStyle(
                    color: JarvisTheme.primaryCyan,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5),
              ),
            ),
            if (notes.isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('No notes yet. Say "remember that..." to add one.',
                    style: TextStyle(color: Colors.white60)),
              ),
            ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.4),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: notes.length,
                itemBuilder: (ctx, i) => ListTile(
                  leading: const Icon(Icons.sticky_note_2_outlined,
                      color: JarvisTheme.primaryCyan),
                  title: Text(notes[i].text, style: const TextStyle(color: Colors.white)),
                  subtitle: Text(
                    '${notes[i].createdAt.toLocal()}'.split('.')[0],
                    style: const TextStyle(color: Colors.white38, fontSize: 11),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_assistantName.toUpperCase()),
        actions: [
          IconButton(
            icon: const Icon(Icons.sticky_note_2_outlined),
            tooltip: 'Notes',
            onPressed: _showNotes,
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: 'Settings',
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          ),
        ],
      ),
      body: Stack(
        children: [
          Column(
            children: [
              // Orb / status area
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: JarvisOrb(
                  isListening: _isListening,
                  isThinking: _isThinking,
                  isSpeaking: _isSpeaking,
                ),
              ),
              if (_partialText.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    _partialText,
                    style: const TextStyle(color: Colors.white54, fontStyle: FontStyle.italic),
                  ),
                ),
              // Chat messages
              Expanded(
                child: ListView.builder(
                  controller: _scrollController,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  itemCount: _messages.length,
                  itemBuilder: (ctx, i) => ChatBubble(message: _messages[i]),
                ),
              ),
              // Input row
              Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _textController,
                        style: const TextStyle(color: Colors.white),
                        decoration: const InputDecoration(
                          hintText: 'Type a command or message...',
                          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        ),
                        onSubmitted: _handleInput,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filled(
                      onPressed: () => _handleInput(_textController.text),
                      icon: const Icon(Icons.send),
                    ),
                    const SizedBox(width: 4),
                    IconButton.filledTonal(
                      onPressed: _toggleListening,
                      style: IconButton.styleFrom(
                        backgroundColor: _isListening
                            ? JarvisTheme.errorRed
                            : JarvisTheme.accentBlue,
                      ),
                      icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
                    ),
                  ],
                ),
              ),
            ],
          ),

          // ASCII shutdown overlay
          if (_showAsciiOutro)
            Container(
              color: Colors.black87,
              child: const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.power_settings_new,
                        color: JarvisTheme.primaryCyan, size: 64),
                    SizedBox(height: 16),
                    Text(
                      '[ SYSTEMS POWERING DOWN ]',
                      style: TextStyle(
                          color: JarvisTheme.primaryCyan,
                          fontFamily: 'monospace',
                          fontSize: 16,
                          letterSpacing: 2),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Goodbye, Sir.',
                      style: TextStyle(color: Colors.white54),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
