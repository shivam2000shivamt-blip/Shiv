import 'package:flutter/material.dart';
import '../utils/theme.dart';

/// An animated pulsing circular "core" reminiscent of JARVIS/Iron Man UI.
/// Color and pulse speed change based on state.
class JarvisOrb extends StatefulWidget {
  final bool isListening;
  final bool isThinking;
  final bool isSpeaking;

  const JarvisOrb({
    super.key,
    required this.isListening,
    required this.isThinking,
    required this.isSpeaking,
  });

  @override
  State<JarvisOrb> createState() => _JarvisOrbState();
}

class _JarvisOrbState extends State<JarvisOrb> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Color get _color {
    if (widget.isListening) return JarvisTheme.errorRed;
    if (widget.isThinking) return Colors.orangeAccent;
    if (widget.isSpeaking) return Colors.greenAccent;
    return JarvisTheme.primaryCyan;
  }

  String get _statusText {
    if (widget.isListening) return 'LISTENING...';
    if (widget.isThinking) return 'PROCESSING...';
    if (widget.isSpeaking) return 'SPEAKING...';
    return 'STANDBY';
  }

  @override
  Widget build(BuildContext context) {
    final speedFactor = (widget.isListening || widget.isThinking || widget.isSpeaking) ? 0.5 : 1.0;

    return Column(
      children: [
        AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final t = _controller.value;
            final pulse = (1 + (0.15 * (1 - (t - 0.5).abs() * 2))) * speedFactor + (1 - speedFactor);
            return Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    _color.withOpacity(0.9),
                    _color.withOpacity(0.1),
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: _color.withOpacity(0.6),
                    blurRadius: 30 * pulse,
                    spreadRadius: 5 * pulse,
                  ),
                ],
              ),
              child: Center(
                child: Container(
                  width: 50 * pulse,
                  height: 50 * pulse,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _color,
                    boxShadow: [
                      BoxShadow(
                        color: _color.withOpacity(0.8),
                        blurRadius: 15,
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 8),
        Text(
          _statusText,
          style: TextStyle(
            color: _color,
            fontSize: 12,
            fontWeight: FontWeight.bold,
            letterSpacing: 3,
          ),
        ),
      ],
    );
  }
}
