import 'package:google_generative_ai/google_generative_ai.dart';
import 'prefs_service.dart';

/// Wrapper around Google Generative AI (Gemini) using the user's OWN API key.
/// The key is never hardcoded - it is read from SharedPreferences
/// (set by the user in Settings screen).
class GeminiService {
  GenerativeModel? _model;
  ChatSession? _chat;
  String? _loadedKey;

  /// Ensures the model/chat session is initialized with the latest
  /// API key from settings. Returns false if no key is set.
  Future<bool> _ensureInit() async {
    final apiKey = await PrefsService.getApiKey();
    if (apiKey == null || apiKey.isEmpty) {
      return false;
    }

    // Re-init only if key changed or not yet initialized
    if (_model == null || _loadedKey != apiKey) {
      _loadedKey = apiKey;
      _model = GenerativeModel(
        // Using the latest fast Gemini model
        model: 'gemini-2.0-flash',
        apiKey: apiKey,
        generationConfig: GenerationConfig(
          temperature: 0.9,
          maxOutputTokens: 512,
        ),
        systemInstruction: Content.system(
          'You are JARVIS, a witty, loyal, highly intelligent AI assistant '
          'inspired by Iron Man\'s JARVIS. Keep responses concise (2-4 '
          'sentences) since they will be spoken aloud via text-to-speech. '
          'Be helpful, slightly formal but warm, and occasionally witty. '
          'Address the user respectfully.',
        ),
      );
      _chat = _model!.startChat();
    }
    return true;
  }

  /// Sends a message to Gemini and returns the text reply.
  /// Returns an error string (never throws) so the UI can speak it.
  Future<String> sendMessage(String message) async {
    final ok = await _ensureInit();
    if (!ok) {
      return "I don't have a Gemini API key configured yet. "
          "Please open Settings and add your API key, Sir.";
    }

    try {
      final response = await _chat!.sendMessage(Content.text(message));
      final text = response.text;
      if (text == null || text.trim().isEmpty) {
        return "I received an empty response. Could you rephrase that?";
      }
      return text.trim();
    } catch (e) {
      final msg = e.toString();
      if (msg.contains('API_KEY_INVALID') || msg.contains('400')) {
        return "Your Gemini API key seems invalid. Please check it in "
            "Settings, Sir.";
      }
      if (msg.contains('429') || msg.contains('quota')) {
        return "I've hit the API rate limit. Please try again in a "
            "moment, Sir.";
      }
      if (msg.contains('SocketException') ||
          msg.contains('Network') ||
          msg.contains('Failed host lookup')) {
        return "I can't reach the internet right now, Sir. Please check "
            "your connection.";
      }
      return "Something went wrong while thinking: ${msg.length > 100 ? msg.substring(0, 100) : msg}";
    }
  }

  /// Resets the conversation history (new chat session).
  Future<void> resetChat() async {
    if (_model != null) {
      _chat = _model!.startChat();
    }
  }

  /// Quick validation call to verify an API key works.
  static Future<bool> validateKey(String apiKey) async {
    try {
      final model = GenerativeModel(model: 'gemini-2.0-flash', apiKey: apiKey);
      final res = await model.generateContent([Content.text('Hello')]);
      return res.text != null;
    } catch (_) {
      return false;
    }
  }
}
