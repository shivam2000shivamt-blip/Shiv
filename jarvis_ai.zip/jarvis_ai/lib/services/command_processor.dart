import 'package:math_expressions/math_expressions.dart';
import 'device_service.dart';
import 'gemini_service.dart';
import 'notes_service.dart';
import '../utils/jokes_data.dart';
import 'prefs_service.dart';

/// Result of processing a command - text to speak/display, and whether
/// it was handled locally (true) or by Gemini AI (false).
class CommandResult {
  final String response;
  final bool handledLocally;
  CommandResult(this.response, this.handledLocally);
}

/// Central brain: takes raw user text, decides what to do.
/// Local/offline commands (time, date, jokes, open app, weather, notes,
/// search) are handled instantly without using the Gemini API.
/// Everything else is routed to Gemini.
class CommandProcessor {
  final DeviceService device = DeviceService();
  final GeminiService gemini = GeminiService();

  Future<CommandResult> process(String input) async {
    final text = input.toLowerCase().trim();
    if (text.isEmpty) {
      return CommandResult("I didn't catch that, Sir.", true);
    }

    final assistantName = await PrefsService.getAssistantName();
    final userName = await PrefsService.getUserName();

    // ---- Greetings ----
    if (_matches(text, ['hello', 'hi', 'hey jarvis', 'hey'])) {
      return CommandResult(
          "Hello, $userName. How can I assist you today?", true);
    }

    // ---- Time ----
    if (_matches(text, ['what time', 'current time', 'tell me the time'])) {
      return CommandResult("It's currently ${device.getTime()}.", true);
    }

    // ---- Date ----
    if (_matches(text, ['what date', 'today\'s date', 'what day is it'])) {
      return CommandResult("Today is ${device.getDate()}.", true);
    }

    // ---- Battery ----
    if (_matches(text, ['battery', 'battery level', 'battery percentage'])) {
      final level = await device.getBatteryLevel();
      if (level < 0) {
        return CommandResult("I couldn't read the battery level, Sir.", true);
      }
      return CommandResult("The battery is at $level percent.", true);
    }

    // ---- Weather ----
    if (_matches(text, ['weather', 'temperature outside', 'how hot is it', 'how cold is it'])) {
      final w = await device.getWeather();
      return CommandResult(w, true);
    }

    // ---- Jokes ----
    if (_matches(text, ['joke', 'make me laugh', 'tell me something funny'])) {
      return CommandResult(JokesData.random(), true);
    }

    // ---- Network status ----
    if (_matches(text, ['internet connected', 'am i online', 'network status', 'wifi status'])) {
      final connected = await device.isConnected();
      return CommandResult(
        connected
            ? "Yes, you're connected to the internet, Sir."
            : "No internet connection detected, Sir.",
        true,
      );
    }

    // ---- Open website ----
    if (text.startsWith('open ')) {
      final target = text.replaceFirst('open ', '').trim();
      // Try app first, then website
      final appOpened = await device.openApp(target);
      if (appOpened) {
        return CommandResult("Opening $target.", true);
      }
      final webOpened = await device.openWebsite(target);
      if (webOpened) {
        return CommandResult("Opening $target.", true);
      }
      return CommandResult("I couldn't open $target, Sir.", true);
    }

    // ---- Web search ----
    if (text.startsWith('search for ') || text.startsWith('search ') || text.startsWith('google ')) {
      final query = text
          .replaceFirst('search for ', '')
          .replaceFirst('search ', '')
          .replaceFirst('google ', '')
          .trim();
      await device.webSearch(query);
      return CommandResult("Searching the web for $query.", true);
    }

    // ---- YouTube search ----
    if (text.startsWith('play ') || text.contains('on youtube')) {
      final query = text
          .replaceFirst('play ', '')
          .replaceAll('on youtube', '')
          .trim();
      await device.youtubeSearch(query);
      return CommandResult("Playing $query on YouTube.", true);
    }

    // ---- Call ----
    if (text.startsWith('call ')) {
      final number = text.replaceFirst('call ', '').trim();
      final ok = await device.callNumber(number);
      return CommandResult(
          ok ? "Calling $number." : "I couldn't make that call, Sir.", true);
    }

    // ---- WhatsApp message ----
    // Pattern: "send whatsapp message to <number> saying <message>"
    if (text.contains('whatsapp')) {
      final phoneMatch = RegExp(r'(\+?\d{7,15})').firstMatch(text);
      final sayingMatch = RegExp(r'(?:saying|that says|message)\s+(.+)$')
          .firstMatch(text);
      if (phoneMatch != null && sayingMatch != null) {
        final phone = phoneMatch.group(1)!;
        final message = sayingMatch.group(1)!.trim();
        final ok = await device.sendWhatsAppMessage(phone, message);
        return CommandResult(
            ok
                ? "Opening WhatsApp to send your message to $phone."
                : "I couldn't open WhatsApp, Sir.",
            true);
      }
      return CommandResult(
          "Please tell me the number and message, like: "
          "'send whatsapp message to 919876543210 saying hello'.",
          true);
    }

    // ---- NEW FEATURE: Set Alarm ----
    // Patterns: "set an alarm for 7", "set alarm for 7:30 am", "set alarm for 19:45"
    if (text.contains('alarm')) {
      final parsed = _parseTime(text);
      if (parsed != null) {
        final ok = await device.setAlarm(parsed.hour, parsed.minute,
            label: '$assistantName Alarm');
        final timeStr =
            '${parsed.hour.toString().padLeft(2, '0')}:${parsed.minute.toString().padLeft(2, '0')}';
        return CommandResult(
          ok
              ? "Alarm set for $timeStr, $userName."
              : "I couldn't set the alarm, Sir.",
          true,
        );
      }
      return CommandResult(
          "Please tell me the time, like 'set an alarm for 7:30 am'.", true);
    }

    // ---- NEW FEATURE: Set Timer ----
    // Patterns: "set a timer for 5 minutes", "set timer for 30 seconds", "set timer for 2 hours"
    if (text.contains('timer')) {
      final seconds = _parseDurationToSeconds(text);
      if (seconds != null && seconds > 0) {
        final ok = await device.setTimer(seconds, label: '$assistantName Timer');
        return CommandResult(
          ok
              ? "Timer set for ${_formatDuration(seconds)}, $userName."
              : "I couldn't set the timer, Sir.",
          true,
        );
      }
      return CommandResult(
          "Please tell me the duration, like 'set a timer for 5 minutes'.",
          true);
    }

    // ---- NEW FEATURE: Flashlight ----
    if (_matches(text, ['turn on flashlight', 'turn on the flashlight', 'enable flashlight', 'flashlight on'])) {
      final ok = await device.toggleFlashlight(true);
      return CommandResult(
          ok ? "Flashlight turned on, $userName." : "I couldn't access the flashlight, Sir.",
          true);
    }
    if (_matches(text, ['turn off flashlight', 'turn off the flashlight', 'disable flashlight', 'flashlight off'])) {
      final ok = await device.toggleFlashlight(false);
      return CommandResult(
          ok ? "Flashlight turned off, $userName." : "I couldn't access the flashlight, Sir.",
          true);
    }

    // ---- NEW FEATURE: Calculator ----
    // Patterns: "calculate 12 * 5 + 3", "what is 45 divided by 9"
    if (text.startsWith('calculate') || text.startsWith('what is') || text.contains('calculate')) {
      final result = _tryCalculate(text);
      if (result != null) {
        return CommandResult("That equals $result, $userName.", true);
      }
    }


    if (text.startsWith('remember that ') ||
        text.startsWith('note that ') ||
        text.startsWith('remember ') ||
        text.startsWith('add a note')) {
      final note = text
          .replaceFirst('remember that ', '')
          .replaceFirst('note that ', '')
          .replaceFirst('remember ', '')
          .trim();
      if (note.isEmpty) {
        return CommandResult("What would you like me to remember, Sir?", true);
      }
      await NotesService.add(note);
      return CommandResult("Got it. I've noted that down, $userName.", true);
    }

    if (_matches(text, [
      'what did i ask you to remember',
      'read my notes',
      'show my notes',
      'what are my notes',
      'list my notes'
    ])) {
      final notes = await NotesService.getAll();
      if (notes.isEmpty) {
        return CommandResult("You haven't asked me to remember anything yet, Sir.", true);
      }
      final top = notes.take(5).map((n) => n.text).join('. ');
      return CommandResult("Here's what I remember: $top", true);
    }

    if (_matches(text, ['clear my notes', 'delete all notes', 'forget everything'])) {
      await NotesService.clear();
      return CommandResult("All notes cleared, Sir.", true);
    }

    // ---- Identity ----
    if (_matches(text, ['who are you', 'what is your name', 'introduce yourself'])) {
      return CommandResult(
          "I am $assistantName, your personal AI assistant, created to "
          "make your life easier, $userName.",
          true);
    }

    // ---- New chat / reset ----
    if (_matches(text, ['reset chat', 'forget our conversation', 'start over', 'new conversation'])) {
      await gemini.resetChat();
      return CommandResult("Starting fresh. What would you like to talk about?", true);
    }

    // ---- Exit / goodbye (handled in UI for ASCII animation) ----
    if (_matches(text, ['bye', 'goodbye', 'goodbye jarvis', 'shutdown', 'exit'])) {
      return CommandResult("Goodbye, $userName. Shutting down for now.", true);
    }

    // ---- Fallback: send to Gemini AI ----
    final aiResponse = await gemini.sendMessage(input);
    return CommandResult(aiResponse, false);
  }

  bool _matches(String text, List<String> keywords) {
    for (final k in keywords) {
      if (text.contains(k)) return true;
    }
    return false;
  }

  /// Parses phrases like "7", "7:30", "7:30 am", "7 pm", "19:45" into hour/minute.
  _TimeOfDayResult? _parseTime(String text) {
    // Match patterns like "7:30 pm", "7 pm", "7:30", "19:45"
    final regex = RegExp(
        r'(\d{1,2})(?::(\d{2}))?\s*(am|pm|a\.m\.|p\.m\.)?',
        caseSensitive: false);
    final matches = regex.allMatches(text);

    for (final m in matches) {
      final hourStr = m.group(1);
      if (hourStr == null) continue;
      int hour = int.parse(hourStr);
      int minute = m.group(2) != null ? int.parse(m.group(2)!) : 0;
      final meridiem = m.group(3)?.toLowerCase().replaceAll('.', '');

      if (hour > 24 || minute > 59) continue;
      if (hour == 0 && minute == 0 && meridiem == null) continue;

      if (meridiem != null) {
        if (meridiem == 'pm' && hour < 12) hour += 12;
        if (meridiem == 'am' && hour == 12) hour = 0;
      }

      if (hour > 23) continue;
      return _TimeOfDayResult(hour, minute);
    }
    return null;
  }

  /// Parses durations like "5 minutes", "30 seconds", "2 hours", "1 hour 30 minutes"
  int? _parseDurationToSeconds(String text) {
    int totalSeconds = 0;
    bool found = false;

    final hourMatch = RegExp(r'(\d+)\s*hour').firstMatch(text);
    if (hourMatch != null) {
      totalSeconds += int.parse(hourMatch.group(1)!) * 3600;
      found = true;
    }

    final minMatch = RegExp(r'(\d+)\s*min').firstMatch(text);
    if (minMatch != null) {
      totalSeconds += int.parse(minMatch.group(1)!) * 60;
      found = true;
    }

    final secMatch = RegExp(r'(\d+)\s*sec').firstMatch(text);
    if (secMatch != null) {
      totalSeconds += int.parse(secMatch.group(1)!);
      found = true;
    }

    return found ? totalSeconds : null;
  }

  String _formatDuration(int seconds) {
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    final parts = <String>[];
    if (h > 0) parts.add('$h hour${h > 1 ? 's' : ''}');
    if (m > 0) parts.add('$m minute${m > 1 ? 's' : ''}');
    if (s > 0) parts.add('$s second${s > 1 ? 's' : ''}');
    return parts.join(' ');
  }

  /// Tries to evaluate a math expression found in the text.
  /// Returns null if no valid expression found.
  String? _tryCalculate(String text) {
    try {
      // Replace spoken words with operators
      String expr = text
          .replaceFirst('calculate', '')
          .replaceFirst('what is', '')
          .replaceAll('plus', '+')
          .replaceAll('minus', '-')
          .replaceAll('times', '*')
          .replaceAll('multiplied by', '*')
          .replaceAll('divided by', '/')
          .replaceAll('x', '*')
          .trim();

      // Extract only valid math characters
      final match = RegExp(r'[\d+\-*/.() ]+').firstMatch(expr);
      if (match == null) return null;
      final cleanExpr = match.group(0)!.trim();
      if (cleanExpr.isEmpty || !RegExp(r'[\d]').hasMatch(cleanExpr)) return null;
      // Must contain an operator to be worth calculating
      if (!RegExp(r'[+\-*/]').hasMatch(cleanExpr)) return null;

      final parser = Parser();
      final exp = parser.parse(cleanExpr);
      final result = exp.evaluate(EvaluationType.REAL, ContextModel());

      if (result == result.toInt()) {
        return result.toInt().toString();
      }
      return result.toStringAsFixed(2);
    } catch (_) {
      return null;
    }
  }
}

class _TimeOfDayResult {
  final int hour;
  final int minute;
  _TimeOfDayResult(this.hour, this.minute);
}
