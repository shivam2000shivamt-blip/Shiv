import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// A simple note/reminder item.
class JarvisNote {
  final String text;
  final DateTime createdAt;

  JarvisNote({required this.text, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'text': text,
        'createdAt': createdAt.toIso8601String(),
      };

  factory JarvisNote.fromJson(Map<String, dynamic> json) => JarvisNote(
        text: json['text'],
        createdAt: DateTime.parse(json['createdAt']),
      );
}

/// NEW FEATURE: Lets the user say "remember that..." / "note that..."
/// and later "what did I ask you to remember" to recall notes.
class NotesService {
  static const _key = 'jarvis_notes';

  static Future<List<JarvisNote>> getAll() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    return raw
        .map((e) => JarvisNote.fromJson(jsonDecode(e)))
        .toList()
        .reversed
        .toList();
  }

  static Future<void> add(String text) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    final note = JarvisNote(text: text, createdAt: DateTime.now());
    raw.add(jsonEncode(note.toJson()));
    await prefs.setStringList(_key, raw);
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
  }

  static Future<void> deleteAt(int index) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? [];
    // Reversed in getAll, so map index back
    final actualIndex = raw.length - 1 - index;
    if (actualIndex >= 0 && actualIndex < raw.length) {
      raw.removeAt(actualIndex);
      await prefs.setStringList(_key, raw);
    }
  }
}
