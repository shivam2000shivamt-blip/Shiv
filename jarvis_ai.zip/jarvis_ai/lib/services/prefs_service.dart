import 'package:shared_preferences/shared_preferences.dart';

/// Handles persistent app settings (API key, user name, wake word, voice prefs)
class PrefsService {
  static const _keyApiKey = 'gemini_api_key';
  static const _keyUserName = 'user_name';
  static const _keyWakeWord = 'wake_word';
  static const _keySpeechRate = 'speech_rate';
  static const _keyVoicePitch = 'voice_pitch';
  static const _keyAssistantName = 'assistant_name';

  static Future<String?> getApiKey() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyApiKey);
  }

  static Future<void> setApiKey(String key) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyApiKey, key.trim());
  }

  static Future<String> getUserName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyUserName) ?? 'Sir';
  }

  static Future<void> setUserName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyUserName, name.trim());
  }

  static Future<String> getAssistantName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyAssistantName) ?? 'Jarvis';
  }

  static Future<void> setAssistantName(String name) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyAssistantName, name.trim());
  }

  static Future<String> getWakeWord() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_keyWakeWord) ?? 'hey jarvis';
  }

  static Future<void> setWakeWord(String word) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyWakeWord, word.toLowerCase().trim());
  }

  static Future<double> getSpeechRate() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keySpeechRate) ?? 0.5;
  }

  static Future<void> setSpeechRate(double rate) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keySpeechRate, rate);
  }

  static Future<double> getVoicePitch() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(_keyVoicePitch) ?? 1.0;
  }

  static Future<void> setVoicePitch(double pitch) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_keyVoicePitch, pitch);
  }
}
