import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:android_intent_plus/android_intent.dart';
import 'package:android_intent_plus/flag.dart';
import 'package:torch_light/torch_light.dart';
import 'dart:convert';

/// Handles device-level actions: time, date, battery, weather,
/// app launching, web search, network status.
class DeviceService {
  final Battery _battery = Battery();

  String getTime() {
    final now = DateTime.now();
    return DateFormat('h:mm a').format(now);
  }

  String getDate() {
    final now = DateTime.now();
    return DateFormat('EEEE, MMMM d, y').format(now);
  }

  Future<int> getBatteryLevel() async {
    try {
      return await _battery.batteryLevel;
    } catch (_) {
      return -1;
    }
  }

  Future<BatteryState> getBatteryState() async {
    return await _battery.batteryState;
  }

  Future<bool> isConnected() async {
    final result = await Connectivity().checkConnectivity();
    return result != ConnectivityResult.none;
  }

  /// Opens a web search for the given query in the default browser.
  Future<bool> webSearch(String query) async {
    final uri = Uri.parse(
        'https://www.google.com/search?q=${Uri.encodeComponent(query)}');
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  /// Opens YouTube search for the given query.
  Future<bool> youtubeSearch(String query) async {
    final uri = Uri.parse(
        'https://www.youtube.com/results?search_query=${Uri.encodeComponent(query)}');
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  /// Opens a website by name (e.g., "open instagram").
  Future<bool> openWebsite(String siteName) async {
    String url = siteName.trim().toLowerCase();
    if (!url.startsWith('http')) {
      if (!url.contains('.')) {
        url = '$url.com';
      }
      url = 'https://$url';
    }
    final uri = Uri.parse(url);
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  /// Attempts to open an installed Android app by package-like name.
  /// Falls back gracefully if not found.
  Future<bool> openApp(String appName) async {
    try {
      final name = appName.toLowerCase().trim();
      // Common app package mappings
      final Map<String, String> packages = {
        'whatsapp': 'com.whatsapp',
        'youtube': 'com.google.android.youtube',
        'instagram': 'com.instagram.android',
        'facebook': 'com.facebook.katana',
        'chrome': 'com.android.chrome',
        'gmail': 'com.google.android.gm',
        'maps': 'com.google.android.apps.maps',
        'camera': 'com.android.camera',
        'settings': 'com.android.settings',
        'play store': 'com.android.vending',
        'spotify': 'com.spotify.music',
        'telegram': 'org.telegram.messenger',
      };

      final pkg = packages[name];
      if (pkg == null) return false;

      final intent = AndroidIntent(
        action: 'action_main',
        package: pkg,
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Sends a WhatsApp message to a phone number (with country code, no +).
  Future<bool> sendWhatsAppMessage(String phone, String message) async {
    try {
      final cleanPhone = phone.replaceAll(RegExp(r'[^0-9]'), '');
      final uri = Uri.parse(
          'https://wa.me/$cleanPhone?text=${Uri.encodeComponent(message)}');
      return await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {
      return false;
    }
  }

  /// Opens dialer with a phone number.
  Future<bool> callNumber(String phone) async {
    final uri = Uri(scheme: 'tel', path: phone);
    return await launchUrl(uri);
  }

  /// Fetches weather using Open-Meteo (free, no API key needed).
  Future<String> getWeather() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return "Location services are disabled, Sir. I can't fetch weather.";
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return "I need location permission to fetch the weather, Sir.";
        }
      }

      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
      );

      final url = Uri.parse(
          'https://api.open-meteo.com/v1/forecast?latitude=${pos.latitude}&longitude=${pos.longitude}&current_weather=true');
      final res = await http.get(url);

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final current = data['current_weather'];
        final temp = current['temperature'];
        final windSpeed = current['windspeed'];
        final code = current['weathercode'];
        final condition = _weatherCodeToText(code);

        return "It's currently $temp degrees Celsius with $condition, "
            "and wind speed of $windSpeed km/h.";
      }
      return "I couldn't fetch the weather right now, Sir.";
    } catch (e) {
      return "I ran into an issue getting the weather: ${e.toString()}";
    }
  }

  String _weatherCodeToText(int code) {
    if (code == 0) return 'clear skies';
    if (code <= 3) return 'partly cloudy conditions';
    if (code <= 49) return 'foggy conditions';
    if (code <= 69) return 'rain';
    if (code <= 79) return 'snow';
    if (code <= 99) return 'thunderstorms';
    return 'unusual conditions';
  }

  /// NEW: Sets an alarm using Android's built-in Clock app via Intent.
  /// hour: 0-23, minute: 0-59
  Future<bool> setAlarm(int hour, int minute, {String label = 'Jarvis Alarm'}) async {
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.SET_ALARM',
        arguments: {
          'android.intent.extra.alarm.HOUR': hour,
          'android.intent.extra.alarm.MINUTES': minute,
          'android.intent.extra.alarm.MESSAGE': label,
          'android.intent.extra.alarm.SKIP_UI': false,
        },
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// NEW: Starts a countdown timer using Android's built-in Clock app.
  Future<bool> setTimer(int seconds, {String label = 'Jarvis Timer'}) async {
    try {
      final intent = AndroidIntent(
        action: 'android.intent.action.SET_TIMER',
        arguments: {
          'android.intent.extra.alarm.LENGTH': seconds,
          'android.intent.extra.alarm.MESSAGE': label,
          'android.intent.extra.alarm.SKIP_UI': true,
        },
        flags: [Flag.FLAG_ACTIVITY_NEW_TASK],
      );
      await intent.launch();
      return true;
    } catch (_) {
      return false;
    }
  }

  /// NEW: Toggles the device flashlight on/off.
  Future<bool> toggleFlashlight(bool turnOn) async {
    try {
      if (turnOn) {
        await TorchLight.enableTorch();
      } else {
        await TorchLight.disableTorch();
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> isFlashlightAvailable() async {
    try {
      return await TorchLight.isTorchAvailable();
    } catch (_) {
      return false;
    }
  }
}
