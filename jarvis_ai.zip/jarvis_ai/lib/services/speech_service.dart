import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';
import 'prefs_service.dart';

/// Wraps speech-to-text (listening) and text-to-speech (speaking).
class SpeechService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();

  bool _speechEnabled = false;
  bool get speechEnabled => _speechEnabled;
  bool get isListening => _speech.isListening;

  Future<bool> init() async {
    _speechEnabled = await _speech.initialize(
      onError: (err) => print('STT error: $err'),
      onStatus: (status) => print('STT status: $status'),
    );

    final rate = await PrefsService.getSpeechRate();
    final pitch = await PrefsService.getVoicePitch();
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(rate);
    await _tts.setPitch(pitch);
    await _tts.setVolume(1.0);

    return _speechEnabled;
  }

  /// Starts listening; calls [onResult] with the final recognized text.
  Future<void> startListening({
    required Function(String text) onResult,
    Function(String partial)? onPartial,
  }) async {
    if (!_speechEnabled) return;
    await _speech.listen(
      onResult: (result) {
        if (result.finalResult) {
          onResult(result.recognizedWords);
        } else {
          onPartial?.call(result.recognizedWords);
        }
      },
      listenFor: const Duration(seconds: 15),
      pauseFor: const Duration(seconds: 3),
      partialResults: true,
      cancelOnError: true,
      listenMode: stt.ListenMode.confirmation,
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
  }

  Future<void> reloadVoiceSettings() async {
    final rate = await PrefsService.getSpeechRate();
    final pitch = await PrefsService.getVoicePitch();
    await _tts.setSpeechRate(rate);
    await _tts.setPitch(pitch);
  }
}
