/// A collection of local jokes - no internet required.
class JokesData {
  static const List<String> jokes = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I told my computer I needed a break, and now it won't stop sending me KitKat ads.",
    "Why did the AI go to therapy? It had too many deep learning issues.",
    "I would tell you a UDP joke, but you might not get it.",
    "Why was the JavaScript developer sad? Because they didn't know how to 'null' their feelings.",
    "There are 10 types of people in this world: those who understand binary, and those who don't.",
    "Why do robots make great comedians? They've got excellent timing circuits.",
    "I'm not a robot... but if I were, I'd at least have better posture than you, Sir.",
    "Why did the computer go to the doctor? It had a virus.",
    "Artificial intelligence is no match for natural stupidity. Present company excluded, of course.",
  ];

  static String random() {
    jokes.shuffle();
    return jokes.first;
  }
}
